
import Router from "./Components/Router";



function App() {
    return (
        <div>
            <Router />
    
        </div>
    );
}

export default App;
